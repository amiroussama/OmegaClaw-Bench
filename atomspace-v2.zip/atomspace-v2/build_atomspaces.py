"""Generate the two FreeCiv atomspaces from primary sources.

  Atomspace A  rulebook.metta      the complete baseline rulebook + instructions any
                                   player gets before the game — laws at (stv 1.0 1.0),
                                   GENERATED from FreeCiv's own ruleset files (ruleset/)
  Atomspace B  world_turn1.metta   A + this overlay = everything visible on the board in
                                   the real captured initial state (samples/real_state_turn1.json),
                                   observations at (stv 1.0 0.99)

Also writes rows.json — one record per atom {space, sheet, entity, atom, en, f, c, source}
— which build_spreadsheets.py mirrors into the review workbooks.

Conventions (chainable inside lib_pln's verified subset):
  * Inheritance/Implication word-form only; multi-premise laws are curried.
  * Every atom is paired with a plain-English rendering (the `; EN:` comment / the
    spreadsheet column) — the atomspace stays canonical, the translation is deterministic.
  * Instance atoms (Unit_102, Tile_14_42) live ONLY in the world overlay: rebuilt from the
    state feed every turn, flushed at game end. Nothing in the rulebook names an instance.

Usage: python3 build_atomspaces.py            (stdlib only)
"""

import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
RS = os.path.join(HERE, "ruleset")
CAPTURE = os.path.join(os.path.dirname(HERE), "OmegaClaw-Core",
                       "benchmarks", "freeciv", "samples", "real_state_turn1.json")

# --------------------------------------------------------------- ruleset parsing

def _clean(v):
    v = v.strip()
    m = re.match(r'_\(\s*"(.*)"\s*\)\s*$', v)
    if m:
        return m.group(1)
    return v.strip('"')


def parse_ruleset(path):
    """[section] -> {key: scalar-or-list, '_tables': {key: [row-dicts]}}"""
    sections, cur, curname = {}, None, None
    lines = open(path, encoding="utf-8").read().splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if s.startswith(";") or not s:
            i += 1
            continue
        m = re.match(r"\[(\w+)\]", s)
        if m:
            curname = m.group(1)
            cur = sections.setdefault(curname, {"_tables": {}})
            i += 1
            continue
        m = re.match(r"(\w+)\s*=\s*(.*)$", s)
        if m and cur is not None:
            key, val = m.group(1), m.group(2).strip()
            # table form:  key = \n { "col", ... \n rows \n }
            if val == "" or val.startswith("{"):
                block = val
                while "}" not in block and i + 1 < len(lines):
                    i += 1
                    block += "\n" + lines[i]
                rows = []
                body = block[block.find("{") + 1: block.rfind("}")]
                brows = [r for r in body.splitlines() if r.strip() and not r.strip().startswith(";")]
                if brows:
                    cols = re.findall(r'"([^"]*)"', brows[0])
                    for r in brows[1:]:
                        vals = re.findall(r'_\(\s*"([^"]*)"\s*\)|"([^"]*)"', r)
                        vals = [a or b for a, b in vals]
                        if vals:
                            rows.append(dict(zip(cols, vals)) if len(cols) == len(vals) else {"_": vals})
                cur["_tables"][key] = rows
                i += 1
                continue
            # comma-list that may continue on following lines
            while val.rstrip().endswith(",") and i + 1 < len(lines):
                i += 1
                val += " " + lines[i].strip()
            val = val.split(";")[0].strip() if '"' not in val else val
            if '","' in val or (val.count('"') >= 4):
                cur[key] = [_clean('"' + p + '"') for p in re.findall(r'"([^"]*)"', val)]
            else:
                cur[key] = _clean(val)
        i += 1
    return sections


def tok(prefix, name):
    return prefix + "_" + re.sub(r"[^A-Za-z0-9_]", "", str(name).replace(" ", ""))


def type_tok(name):   # matches adapter.py's live tokens: proxy sends lowercase names
    return "Type_" + re.sub(r"[^a-z0-9_]", "", str(name).lower().replace(" ", ""))


# ------------------------------------------------------------------- atom store

ROWS = []


def atom(space, sheet, entity, s, en, f, c, source):
    ROWS.append({"space": space, "sheet": sheet, "entity": entity, "atom": s,
                 "en": en, "f": f, "c": c, "source": source})


def law(sheet, entity, s, en, source, f=1.0, c=1.0):
    atom("A", sheet, entity, s, en, f, c, source)


def obs(sheet, entity, s, en, source, f=1.0, c=0.99):
    atom("B", sheet, entity, s, en, f, c, source)


# ------------------------------------------------------------------- A: rulebook

def build_techs():
    techs = parse_ruleset(os.path.join(RS, "techs.ruleset"))
    names = {}
    for sec, d in techs.items():
        if not sec.startswith("advance_") or "name" not in d:
            continue
        name = d["name"]
        t = tok("Tech", name)
        names[sec] = name
        src = f"techs.ruleset [{sec}]"
        law("Techs", name, f"(Inheritance {t} Technology)", f"{name} is a technology.", src)
        r1, r2 = d.get("req1", "None"), d.get("req2", "None")
        if r1 == "None" and r2 == "None":
            law("Techs", name, f"(Inheritance {t} Researchable)",
                f"{name} can be researched from the very start (no prerequisites).", src)
        elif r2 == "None":
            law("Techs", name,
                f"(Implication (Inheritance {tok('Tech', r1)} Researched) (Inheritance {t} Researchable))",
                f"Once you know {r1}, you can research {name}.", src)
        else:
            law("Techs", name,
                f"(Implication (Inheritance {tok('Tech', r1)} Researched) "
                f"(Implication (Inheritance {tok('Tech', r2)} Researched) (Inheritance {t} Researchable)))",
                f"Once you know both {r1} and {r2}, you can research {name}.", src)
    return names


FLAG_CAPS = {
    "Cities": ("CanFoundCity", "can found new cities"),
    "Settlers": ("CanImproveTerrain", "can build roads/irrigation and improve terrain"),
    "Workers": ("CanImproveTerrain", "can build roads/irrigation and improve terrain"),
    "TradeRoute": ("CanEstablishTrade", "can establish trade routes"),
    "HelpWonder": ("CanHelpWonder", "can help finish a wonder"),
    "Diplomat": ("CanDoDiplomacy", "can perform diplomat actions"),
    "Spy": ("CanSpy", "can perform espionage"),
    "Paratroopers": ("CanParadrop", "can paradrop"),
}


def build_units():
    units = parse_ruleset(os.path.join(RS, "units.ruleset"))
    for sec, d in units.items():
        if not sec.startswith("unit_") or "name" not in d:
            continue
        name = d["name"]
        t = type_tok(name)
        src = f"units.ruleset [{sec}]"
        cls = d.get("class", "?")
        law("Units", name, f"(Inheritance {t} UnitType)", f"{name} is a kind of unit.", src)
        law("Units", name, f"(Inheritance {t} Class_{cls})", f"{name} is a {cls.lower()} unit.", src)
        stats = [("Attack", d.get("attack")), ("Defense", d.get("defense")),
                 ("Moves", d.get("move_rate")), ("HP", d.get("hitpoints")),
                 ("Firepower", d.get("firepower")), ("BuildCost", d.get("build_cost"))]
        en_bits = []
        for label, v in stats:
            if v is None:
                continue
            law("Units", name, f"(Inheritance {t} ({label} {v}))",
                f"{name} has {label.lower().replace('buildcost','build cost')} {v}.", src)
            en_bits.append(f"{label.lower()} {v}")
        pc = d.get("pop_cost")
        if pc and str(pc) != "0":
            law("Units", name, f"(Inheritance {t} (PopCost {pc}))",
                f"Building a {name} costs {pc} city population.", src)
        # tech requirement -> buildability law (curried with owning a city)
        reqs = [r for r in d["_tables"].get("reqs", []) if r.get("type") == "Tech"]
        if reqs:
            r = reqs[0]["name"]
            law("Units", name, f"(Inheritance {t} (RequiresTech {tok('Tech', r)}))",
                f"{name} requires the {r} technology.", src)
            law("Units", name,
                f"(Implication (Inheritance $c IsCity) (Implication (Inheritance {tok('Tech', r)} Researched) "
                f"(Inheritance $c (CanBuild {t}))))",
                f"A city can build {name} once {r} is researched.", src)
        else:
            law("Units", name, f"(Implication (Inheritance $c IsCity) (Inheritance $c (CanBuild {t})))",
                f"Any city can build {name} from the start.", src)
        ob = d.get("obsolete_by", "None")
        if ob and ob != "None":
            law("Units", name, f"(Inheritance {t} (ObsoletedBy {type_tok(ob)}))",
                f"{name} is made obsolete by {ob}.", src)
        flags = d.get("flags", [])
        flags = flags if isinstance(flags, list) else [flags]
        for fl in flags:
            if fl in FLAG_CAPS:
                cap, desc = FLAG_CAPS[fl]
                law("Units", name, f"(Implication (Inheritance $u {t}) (Inheritance $u {cap}))",
                    f"Every {name} {desc}.", src)


def build_terrain():
    terr = parse_ruleset(os.path.join(RS, "terrain.ruleset"))
    for sec, d in terr.items():
        if not sec.startswith("terrain_") or "name" not in d:
            continue
        name = d["name"]
        t = tok("Terrain", name)
        src = f"terrain.ruleset [{sec}]"
        cls = d.get("class", "?")
        law("Terrain", name, f"(Inheritance {t} TerrainType)", f"{name} is a terrain type.", src)
        law("Terrain", name, f"(Inheritance {t} Class_{cls})", f"{name} is {cls.lower()} terrain.", src)
        for label, key, enw in [("Food", "food", "food"), ("Shield", "shield", "production"),
                                ("Trade", "trade", "trade"), ("MoveCost", "movement_cost", "movement cost"),
                                ("DefenseBonusPct", "defense_bonus", "% defense bonus")]:
            v = d.get(key)
            if v is not None:
                law("Terrain", name, f"(Inheritance {t} ({label} {v}))",
                    f"A worked {name} tile yields {v} {enw}." if label in ("Food", "Shield", "Trade")
                    else f"{name} has {enw} {v}.", src)
        law("Terrain", name,
            f"(Implication (Inheritance $t {t}) (Inheritance $t {'LandTile' if cls == 'Land' else 'WaterTile'}))",
            f"Any tile of {name} is {'land' if cls == 'Land' else 'water'}.", src)
        for key, verb in [("cultivate_result", "cultivating"), ("plant_result", "planting")]:
            r = d.get(key)
            if r and r not in ("no", "None", "yes"):
                law("Terrain", name, f"(Inheritance {t} (TransformsInto {tok('Terrain', r)} By_{verb.split()[0]}))",
                    f"{verb.capitalize()} a {name} tile turns it into {r}.", src)


def build_buildings():
    b = parse_ruleset(os.path.join(RS, "buildings.ruleset"))
    for sec, d in b.items():
        if not sec.startswith("building_") or "name" not in d:
            continue
        name = d["name"]
        t = tok("Building", name)
        src = f"buildings.ruleset [{sec}]"
        genus = d.get("genus", "Improvement")
        law("Buildings", name, f"(Inheritance {t} Genus_{genus})",
            f"{name} is a {'wonder' if 'Wonder' in genus else 'city improvement'}.", src)
        for label, key in [("BuildCost", "build_cost"), ("Upkeep", "upkeep")]:
            v = d.get(key)
            if v is not None:
                law("Buildings", name, f"(Inheritance {t} ({label} {v}))",
                    f"{name} {'costs ' + str(v) + ' shields to build' if label == 'BuildCost' else 'has upkeep ' + str(v) + ' gold per turn'}.", src)
        techreqs = [r["name"] for r in d["_tables"].get("reqs", []) if r.get("type") == "Tech"]
        bldreqs = [r["name"] for r in d["_tables"].get("reqs", []) if r.get("type") == "Building"]
        for r in techreqs:
            law("Buildings", name, f"(Inheritance {t} (RequiresTech {tok('Tech', r)}))",
                f"{name} requires the {r} technology.", src)
        for r in bldreqs:
            law("Buildings", name, f"(Inheritance {t} (RequiresBuilding {tok('Building', r)}))",
                f"{name} requires the city to already have a {r}.", src)
        # buildability law, curried over city + every requirement
        concl = f"(Inheritance $c (CanBuild {t}))"
        chain = concl
        for r in bldreqs:
            chain = f"(Implication (Inheritance $c (Has {tok('Building', r)})) {chain})"
        for r in techreqs:
            chain = f"(Implication (Inheritance {tok('Tech', r)} Researched) {chain})"
        chain = f"(Implication (Inheritance $c IsCity) {chain})"
        reqtxt = " and ".join([f"{r} (tech)" for r in techreqs] + [f"a {r}" for r in bldreqs]) or "nothing else"
        law("Buildings", name, chain, f"A city can build {name} once it has {reqtxt}.", src)


CORE = [
    # --- turn structure & the shape of play -----------------------------------
    ("(Inheritance GameFlow (Step_1 ObserveState))", "Each turn: first, observe the visible game state."),
    ("(Inheritance GameFlow (Step_2 ActWithEachUnit))", "Then each of your units may act (move/work/attack) up to its movement allowance."),
    ("(Inheritance GameFlow (Step_3 ManageCitiesAndResearch))", "Then set city production and your one active research target."),
    ("(Inheritance GameFlow (Step_4 EndTurn))", "Then end your turn; the world advances for everyone."),
    ("(Implication (Do (EndTurn Player_Self)) (Inheritance Turn Advanced))", "Ending your turn advances the game to the next turn."),
    # --- founding & cities -----------------------------------------------------
    ("(Implication (Inheritance $u CanFoundCity) (Implication (Inheritance $u (CanNow BuildCity)) (Inheritance $u ReadyToFound)))",
     "A city-founder standing where founding is currently legal is ready to found."),
    ("(Implication (Do (FoundCity $u $t)) (Inheritance $t HasCity))", "Founding a city with a unit on tile T creates a city on T."),
    ("(Implication (Do (FoundCity $u $t)) (Inheritance $u Consumed))", "The founding unit is consumed (settlers cost population)."),
    ("(Implication (Inheritance $t HasCity) (Inheritance $t IsCity))", "A tile with a city on it is a city (for build rules)."),
    ("(Implication (Inheritance $t LandTile) (Inheritance $t CityFoundable))", "Cities can only be founded on land tiles."),
    ("(Inheritance CityFounding (MinDistanceBetweenCities 2))", "New cities must keep a minimum distance from existing cities (server setting citymindist, default 2)."),
    ("(Implication (Inheritance $c IsCity) (Inheritance $c WorksSurroundingTiles))", "A city works its surrounding tiles for food, production, and trade each turn."),
    ("(Inheritance CityGrowth (Rule FoodSurplusAccumulates))", "A city's spare food accumulates; when the food box fills, the city grows by 1 population."),
    ("(Inheritance CityProduction (Rule ShieldsAccumulate))", "A city's production (shields) accumulates toward the unit or building it is making."),
    ("(Implication (Inheritance $c FoodDeficit) (Inheritance $c WillShrinkOrStarve))", "A city losing food will shrink and can starve units."),
    # --- movement, combat, defense --------------------------------------------
    ("(Implication (Do (MoveTo $u $t)) (Inheritance $u (OnTile $t)))", "Moving a unit puts it on the destination tile (costs movement points; terrain move cost applies)."),
    ("(Inheritance Movement (Rule MovesPerTurnByType))", "Each unit gets its type's movement points per turn; an action spends them."),
    ("(Implication (Do (Fortify $u $t)) (Inheritance $t Garrisoned))", "Fortifying a unit in place garrisons that tile (defense bonus)."),
    # --- combat, as executable law (not a placard): type stats lift to units, ---
    # --- modifiers compose numerically, win probability lands in the stv. ------
    # NOTE on variable ordering: each curried law leads with its MOST SELECTIVE
    # premise ((VetLevel ...) exists only for units in a considered battle) so
    # untyped variables never fan out across the whole space.
    ("(Implication (Inheritance $u (VetLevel $v)) (Implication (Inheritance $u $T) "
     "(Implication (Inheritance $T (Attack $a)) (Inheritance $u (AttackPower $a)))))",
     "A combat-relevant unit's base attack power is its type's attack value."),
    ("(Implication (Inheritance $u (VetLevel $v)) (Implication (Inheritance $u $T) "
     "(Implication (Inheritance $T (Defense $d)) (Inheritance $u (DefensePower $d)))))",
     "A combat-relevant unit's base defense power is its type's defense value."),
    ("(Implication (Inheritance $u (VetLevel $v)) (Implication (Inheritance $u $T) "
     "(Implication (Inheritance $T (HP $h)) (Inheritance $u (UnitHP $h)))))",
     "A combat-relevant unit's hit points come from its type."),
    ("(Implication (Inheritance $u (VetLevel $v)) (Implication (Inheritance $u $T) "
     "(Implication (Inheritance $T (Firepower $f)) (Inheritance $u (UnitFirepower $f)))))",
     "A combat-relevant unit's firepower comes from its type."),
    ("(Implication (Inheritance $a (VetLevel $v)) (Implication (Inheritance $a (AttackPower $ap)) "
     "(Inheritance $a (EffectiveAttack (Mul $ap (VetFactor $v))))))",
     "Effective attack = base attack x veterancy factor (green 1.0, veteran 1.5, hardened 1.75, elite 2.0)."),
    ("(Implication (Inheritance $d (FortifyState $fs)) (Implication (Inheritance $d (VetLevel $v)) "
     "(Implication (Inheritance $d (OnTerrainDefBonusPct $pct)) (Implication (Inheritance $d (DefensePower $dp)) "
     "(Inheritance $d (EffectiveDefense (Mul $dp (VetFactor $v) (DefBonusFactor $pct) (FortFactor $fs))))))))",
     "Effective defense = base defense x veterancy x terrain factor (1 + bonus%/100) x fortification (fortified 1.5, else 1.0)."),
    ("(Implication (Do (Attack $a $d)) (Implication (Inheritance $a (EffectiveAttack $A)) "
     "(Implication (Inheritance $d (EffectiveDefense $D)) (Implication (Inheritance $a (UnitFirepower $fa)) "
     "(Implication (Inheritance $d (UnitHP $hd)) (Implication (Inheritance $d (UnitFirepower $fd)) "
     "(Implication (Inheritance $a (UnitHP $ha)) (AsTruth (BattleWinProb $A $D $fa $hd $fd $ha) (Wins $a $d)))))))))",
     "Considering an attack: each round the attacker hits with probability A/(A+D); a hit removes the striker's "
     "firepower from the other side's hit points; first to zero dies. The attacker's full-battle win probability "
     "becomes the TRUTH VALUE (frequency) of (Wins attacker defender)."),
    ("(Implication (Do (Attack $a $d)) (Implication (Inheritance $a (EffectiveAttack $A)) "
     "(Implication (Inheritance $d (EffectiveDefense $D)) (Implication (Inheritance $a (UnitFirepower $fa)) "
     "(Implication (Inheritance $d (UnitHP $hd)) (Implication (Inheritance $d (UnitFirepower $fd)) "
     "(Implication (Inheritance $a (UnitHP $ha)) (Inheritance (Battle $a $d) (OddsBucket (BattleWinProb $A $D $fa $hd $fd $ha))))))))))",
     "The same considered battle is classified symbolically: Favorable (win chance >= 55%), Coinflip (45-55%), or Unfavorable (< 45%) — so strategy rules can chain on it."),
    ("(Implication (Inheritance $t HasCity) (Implication (Inheritance $t NoGarrison) (Inheritance $t MustGarrison)))",
     "A city with no garrison must be garrisoned — an undefended city can be captured outright."),
    ("(Implication (Inheritance $t Garrisoned) (GoalProgress Survive (DefenseAt $t)))", "A garrisoned tile is progress toward surviving."),
    # --- research ---------------------------------------------------------------
    ("(Inheritance Research (Rule OneActiveTech))", "You research one technology at a time; trade output becomes research bulbs."),
    ("(Implication (Do (Research $tech)) (Inheritance $tech Researched))", "Completing research on a technology makes it known (then its dependents become researchable)."),
    ("(Implication (Inheritance $tech Researchable) (GoalProgress Tech (Unlocked $tech)))", "Each newly researchable technology is progress up the tech tree."),
    ("(Implication (Inheritance $tech Researched) (GoalProgress Tech (Gained $tech)))", "Each completed technology is progress up the tech tree."),
    # --- economy ----------------------------------------------------------------
    ("(Inheritance Economy (Rule GoldUpkeep))", "Buildings cost gold upkeep each turn; units cost shield upkeep from their home city; empty treasury sells buildings."),
    ("(Implication (Inheritance $t HasCity) (GoalProgress Expand (CityAt $t)))", "Every founded city is progress toward expansion."),
    # --- visibility & contact ---------------------------------------------------
    ("(Inheritance Vision (Rule UnitsAndCitiesSee))", "You see only what your units and cities can see (fog of war); the rest of the map is unknown, not empty."),
    ("(Inheritance Diplomacy (Rule ContactBeforeNegotiation))", "You must make contact with an opponent before negotiations; messages may be sent anytime."),
    # --- winning and losing -----------------------------------------------------
    ("(Inheritance Victory (By ConquestEliminateAllRivals))", "You win by conquest: eliminate every rival civilization."),
    ("(Inheritance Victory (By SpaceRaceOptional))", "You can also win by space race, if enabled."),
    ("(Implication (Inheritance $p ZeroCitiesAndZeroUnits) (Inheritance $p Eliminated))",
     "A player with no cities and no units is eliminated (this is the duel's win condition)."),
]


def build_core():
    for s, en in CORE:
        law("Core laws", "Rules of play", s, en, "game.ruleset / freeciv manual (classic)")


# ------------------------------------------------------------- B: world overlay

def build_world():
    raw = json.load(open(CAPTURE, encoding="utf-8"))
    src = "samples/real_state_turn1.json"
    obs("World-Meta", "Game", "(Inheritance Turn_1 CurrentTurn)", "It is turn 1.", src + " turn")
    m = raw.get("map", {})
    obs("World-Meta", "Game", f"(Inheritance GameMap (Width {m.get('width')}))",
        f"The map is {m.get('width')} tiles wide.", src + " map.width")
    obs("World-Meta", "Game", f"(Inheritance GameMap (Height {m.get('height')}))",
        f"The map is {m.get('height')} tiles tall.", src + " map.height")

    units = raw.get("units", {})
    for uid, u in sorted(units.items(), key=lambda kv: int(kv[0])):
        if u.get("owner") != raw.get("player_perspective", 0):
            continue
        ut = f"Unit_{uid}"
        obs("World-Units", f"Unit {uid}", f"(Inheritance {ut} {type_tok(u['type'])})",
            f"My unit #{uid} is a {u['type'].rstrip('s') if u['type'] != 'workers' else 'worker'} unit ({u['type']}).",
            f"{src} units[{uid}].type")
        obs("World-Units", f"Unit {uid}", f"(Inheritance {ut} (OnTile Tile_{u['x']}_{u['y']}))",
            f"Unit #{uid} is standing at map square ({u['x']}, {u['y']}).", f"{src} units[{uid}].x,y")
        if u.get("moves_left") is not None:
            obs("World-Units", f"Unit {uid}", f"(Inheritance {ut} (MovesLeft {u['moves_left']}))",
                f"Unit #{uid} has {u['moves_left']} movement points left this turn.", f"{src} units[{uid}].moves_left")

    AFF = {"unit_build_city": ("BuildCity", "found a city right here"),
           "unit_build_road": ("BuildRoad", "build a road here"),
           "unit_build_irrigation": ("Irrigate", "irrigate this tile"),
           "unit_build_mine": ("BuildMine", "mine this tile"),
           "unit_build_base": ("BuildBase", "build a base here"),
           "unit_cultivate": ("Cultivate", "cultivate this tile"),
           "unit_plant": ("Plant", "plant forest on this tile"),
           "unit_pillage": ("Pillage", "pillage this tile"),
           "unit_clean": ("Clean", "clean this tile"),
           "unit_fortify": ("Fortify", "fortify in place"),
           "unit_sentry": ("Sentry", "go on sentry"),
           "unit_skip": ("Skip", "skip its action"),
           "unit_disband": ("Disband", "be disbanded")}
    la = raw.get("legal_actions", {})
    for actor, acts in sorted(la.items(), key=lambda kv: str(kv[0])):
        for a in acts:
            if not a.get("is_valid"):
                continue   # invalid options (with reasons) are knowledge too — quarantined for now
            at = a.get("action_type")
            if at == "unit_move":
                t = a.get("target", {})
                obs("World-Affordances", f"Unit {actor}",
                    f"(Inheritance Unit_{actor} (CanNow (MoveTo Tile_{t.get('x')}_{t.get('y')})))",
                    f"Unit #{actor} can move {t.get('direction', '?').upper()} to ({t.get('x')}, {t.get('y')}) right now.",
                    f"{src} legal_actions[{actor}]")
            elif at in AFF:
                cap, en = AFF[at]
                obs("World-Affordances", f"Unit {actor}",
                    f"(Inheritance Unit_{actor} (CanNow {cap}))",
                    f"Unit #{actor} can {en} right now (the game itself validated this).",
                    f"{src} legal_actions[{actor}]")
            elif at == "tech_research":
                tech = a.get("target", {}).get("tech_name")
                obs("World-Affordances", "Player",
                    f"(Inheritance {tok('Tech', tech)} ResearchableNow)",
                    f"{tech} is available to research right now.", f"{src} legal_actions.player")
            elif at == "diplomacy_message":
                p = a.get("target", {})
                obs("World-Affordances", "Player",
                    f"(Inheritance Player_{p.get('player_id')} (CanNow ReceiveMessage))",
                    f"I can send a diplomatic message to {p.get('player_name')} right now.",
                    f"{src} legal_actions.player")
            elif at == "end_turn":
                obs("World-Affordances", "Player", "(Inheritance Player_0 (CanNow EndTurn))",
                    "I can end my turn.", f"{src} legal_actions.player")

    players = raw.get("players", {})
    me = raw.get("player_perspective", 0)
    obs("World-Diplomacy", "Me", f"(Inheritance Player_{me} Self)",
        f"Player_{me} is me — the agent's own side; all goals and units marked Player_{me} are mine.",
        f"{src} player_perspective")
    for pid, p in sorted(players.items(), key=lambda kv: int(kv[0])):
        pt = f"Player_{pid}"
        who = "I" if int(pid) == me else p.get("name", "?")
        obs("World-Diplomacy", p.get("name", pid), f"(Inheritance {pt} Nation_{tok('', p.get('nation', '?'))[1:]})",
            f"{who} {'am' if int(pid) == me else 'is'} the {p.get('nation')} nation" +
            ("" if int(pid) == me else f" (led by {p.get('name')})") + ".", f"{src} players[{pid}]")
        if int(pid) != me:
            obs("World-Diplomacy", p.get("name", pid), f"(Inheritance {pt} Opponent)",
                f"{p.get('name')} is an opponent.", f"{src} players[{pid}]")
            ds = p.get("diplomatic_status")
            if ds:
                obs("World-Diplomacy", p.get("name", pid), f"(Inheritance {pt} {tok('', ds.title().replace('_', ''))[1:]})",
                    f"I have {'made no contact yet with' if ds == 'no_contact' else ds + ' with'} {p.get('name')}.",
                    f"{src} players[{pid}].diplomatic_status")

    # quarantined — visible in the feed but NOT asserted (rows only, no atoms)
    Q = [("techs.player0 = ['Advanced Flight']", "EXCLUDED — contradicts strategic.tech_level: 0 in the same state (known proxy tech-id artifact)."),
         ("strategic.score = 0 vs strategic_summary.score = 100", "EXCLUDED — the two gauges disagree; score is unknown, not 0 and not 100."),
         ("economic.gold = 0, economic.research = 0", "EXCLUDED — documented proxy-unavailable placeholders (freeciv.md §1); unknown is not zero."),
         ("map.tiles = [] (no terrain visible)", "NOT ASSERTED — terrain simply isn't in this capture; the rulebook's terrain laws stand ready for when it is."),
         ("legal_actions rows with is_valid: false (+ reasons)", "NOT ASSERTED — negative affordances ('cannot board: no transport') are real knowledge; folding them in is future work (needs negation handling).")]
    for what, why in Q:
        ROWS.append({"space": "B", "sheet": "Quarantined", "entity": "—", "atom": "(none)",
                     "en": why, "f": "", "c": "", "source": what})


# ------------------------------------------------------------------ file output

HEADER_A = """; ============================================================================
; ATOMSPACE A — the FreeCiv rulebook. GENERATED — do not hand-edit.
;   source: ruleset/  (freeciv classic ruleset; regen: python3 build_atomspaces.py)
;   Everything here is context-independent LAW at (stv 1.0 1.0): true in every
;   game, every turn. No instance (Unit_102, Tile_x_y) ever appears here.
; ============================================================================
"""

HEADER_B = """; ============================================================================
; ATOMSPACE B overlay — everything visible on the board at the captured initial
; state. GENERATED from samples/real_state_turn1.json — do not hand-edit.
;   Load together with rulebook.metta (B = A + this file).
;   Observations at (stv 1.0 0.99). This layer is EPHEMERAL: rebuilt from the
;   state feed every turn, flushed at game end — instance atoms never persist.
; ============================================================================
"""


def emit(space, path, header, group_name):
    rows = [r for r in ROWS if r["space"] == space and r["atom"] != "(none)"]
    lines = [header]
    lines.append(f"(= ({group_name})")
    lines.append("   (superpose (")
    cur_sheet = None
    for r in rows:
        if r["sheet"] != cur_sheet:
            cur_sheet = r["sheet"]
            lines.append(f"\n     ; ------------------------------ {cur_sheet}")
        lines.append(f"     ; EN: {r['en']}")
        lines.append(f"     ({r['atom']} (stv {r['f']} {r['c']}))")
    lines.append("   )))")
    open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    return len(rows)


def main():
    build_core()
    build_techs()
    build_units()
    build_terrain()
    build_buildings()
    build_world()
    na = emit("A", os.path.join(HERE, "rulebook.metta"), HEADER_A, "rulebook")
    nb = emit("B", os.path.join(HERE, "world_turn1.metta"), HEADER_B, "world-observations")
    json.dump(ROWS, open(os.path.join(HERE, "rows.json"), "w"), indent=0)
    by_sheet = {}
    for r in ROWS:
        by_sheet[r["sheet"]] = by_sheet.get(r["sheet"], 0) + 1
    print(f"Atomspace A (rulebook.metta): {na} atoms")
    print(f"Atomspace B overlay (world_turn1.metta): {nb} atoms")
    for k, v in by_sheet.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
