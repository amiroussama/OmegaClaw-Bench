"""Mirror the generated atomspaces into review spreadsheets.

  atomspace-A-rulebook.xlsx       every law in Atomspace A, one row per atom
  atomspace-B-initial-world.xlsx  self-contained: all of A + the world overlay,
                                  the quarantine list, hypothesis scoring, and
                                  every derived atom from the chain demo

Data mirrors only — no formulas. Run after build_atomspaces.py (+ chain.py --json).
"""

import json
import os

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.dirname(HERE)   # pln-games/
ROWS = json.load(open(os.path.join(HERE, "rows.json")))
TRACE = json.load(open(os.path.join(HERE, "trace_full.json")))

F = "Arial"
HDR_FILL = PatternFill("solid", fgColor="1F3B2C")
HDR_FONT = Font(name=F, bold=True, color="FFFFFF", size=10)
BODY = Font(name=F, size=10)
MONO = Font(name="Courier New", size=9)
WRAP = Alignment(wrap_text=True, vertical="top")
TOP = Alignment(vertical="top")


def sheet_rows(ws, headers, rows, widths, mono_cols=()):
    ws.append(headers)
    for i, h in enumerate(headers, 1):
        c = ws.cell(row=1, column=i)
        c.font, c.fill = HDR_FONT, HDR_FILL
    for r in rows:
        ws.append(r)
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.font = MONO if (c.column in mono_cols) else BODY
            c.alignment = WRAP if (c.column in mono_cols or c.column == len(headers) - 3) else TOP
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions


def add_readme(wb, title, lines):
    ws = wb.active
    ws.title = "README"
    ws["A1"] = title
    ws["A1"].font = Font(name=F, bold=True, size=14)
    for i, ln in enumerate(lines, 3):
        ws.cell(row=i, column=1, value=ln).font = BODY
    ws.column_dimensions["A"].width = 120


def atom_sheets(wb, space, sheets):
    for name in sheets:
        rows = [r for r in ROWS if r["space"] == space and r["sheet"] == name]
        if not rows:
            continue
        ws = wb.create_sheet(name[:31])
        sheet_rows(ws,
                   ["Entity", "Atom (PLN word-form)", "Plain English", "f", "c", "Source"],
                   [[r["entity"], r["atom"], r["en"], r["f"], r["c"], r["source"]] for r in rows],
                   [22, 72, 64, 6, 6, 34], mono_cols=(2,))


def en_derived(atom):
    """Best-effort plain English for a derived atom string."""
    import re
    m = re.match(r"\(Recommend (\S+) FoundCityNow\)", atom)
    if m: return f"Recommendation: {m.group(1)} should found a city now."
    m = re.match(r"\(Recommend Player_0 \(Research (\S+)\)\)", atom)
    if m: return f"Recommendation: research {m.group(1).replace('Tech_','')}."
    m = re.match(r"\(GoalProgress (\S+) \((\w+) (\S+)\)\)", atom)
    if m: return f"Progress toward the {m.group(1)} goal: {m.group(2).lower()} {m.group(3).replace('Tech_','').replace('Tile_','tile ')}."
    m = re.match(r"\(Inheritance (\S+) Researchable\)", atom)
    if m: return f"{m.group(1).replace('Tech_','')} is now researchable."
    m = re.match(r"\(Inheritance (\S+) Researched\)", atom)
    if m: return f"(Predicted) {m.group(1).replace('Tech_','')} is known."
    m = re.match(r"\(Inheritance (\S+) ReadyToFound\)", atom)
    if m: return f"{m.group(1)} is ready to found a city."
    m = re.match(r"\(Inheritance (\S+) CanFoundCity\)", atom)
    if m: return f"{m.group(1)} is capable of founding cities."
    m = re.match(r"\(Inheritance (\S+) CanImproveTerrain\)", atom)
    if m: return f"{m.group(1)} can improve terrain."
    m = re.match(r"\(Inheritance (\S+) HasCity\)", atom)
    if m: return f"(Predicted) there is a city at {m.group(1).replace('Tile_','tile ')}."
    m = re.match(r"\(Inheritance (\S+) Consumed\)", atom)
    if m: return f"(Predicted) {m.group(1)} is used up by the action."
    m = re.match(r"\(Wins (\S+) (\S+)\)", atom)
    if m: return f"If {m.group(1)} attacks {m.group(2)}, it wins the whole battle with probability = this atom's frequency (f)."
    m = re.match(r"\(Inheritance \(Battle (\S+) (\S+)\) (\w+)\)", atom)
    if m: return f"The considered battle {m.group(1)} vs {m.group(2)} is {m.group(3).lower()} for the attacker."
    m = re.match(r"\(Recommend (\S+) HoldPosition\)", atom)
    if m: return f"Recommendation: {m.group(1)} should NOT attack — hold position."
    m = re.match(r"\(Recommend (\S+) \(PressAttack (\S+)\)\)", atom)
    if m: return f"Recommendation: {m.group(1)} should attack {m.group(2)}."
    m = re.match(r"\(Inheritance (\S+) \((EffectiveAttack|EffectiveDefense|AttackPower|DefensePower|UnitHP|UnitFirepower) (\S+)\)\)", atom)
    if m: return f"{m.group(1)} has {re.sub(r'(?<!^)(?=[A-Z])', ' ', m.group(2)).lower()} {m.group(3)}."
    if atom.startswith("(Implication"):
        return "Derived intermediate rule (curried step — one premise already satisfied)."
    return ""


def main():
    stamp = "Generated 2026-07-17 by build_atomspaces.py / chain.py — regenerate with those scripts; do not hand-edit."
    counts = {}
    for r in ROWS:
        counts[r["sheet"]] = counts.get(r["sheet"], 0) + 1

    # ---------------- A
    wb = Workbook()
    add_readme(wb, "Atomspace A — the FreeCiv rulebook (laws at confidence 1)", [
        "One row per atom. Every law any player is given before the game starts: rules of play, all 87 technologies,",
        "all 52 unit types, all 14 terrain types, all 68 buildings/wonders — generated from FreeCiv's own classic",
        "ruleset files (atomspace-v2/ruleset/, GPL data from the freeciv project).",
        "",
        f"Core laws & instructions: {counts.get('Core laws',0)}   Techs: {counts.get('Techs',0)}   Units: {counts.get('Units',0)}   "
        f"Terrain: {counts.get('Terrain',0)}   Buildings: {counts.get('Buildings',0)}   — total {sum(counts.get(k,0) for k in ('Core laws','Techs','Units','Terrain','Buildings'))} atoms.",
        "",
        "Conventions: Inheritance/Implication word-form only (fires under lib_pln |~); multi-premise laws curried;",
        "no instance (Unit_102, Tile_x_y) appears in this space — laws are context-independent templates.",
        "Known gaps: building/wonder EFFECT semantics (effects.ruleset) not yet encoded (cost/upkeep/prereqs are);",
        "combat is one summary law; ruleset assumed = classic (re-point build_atomspaces.py if the stack pins another).",
        "",
        stamp,
    ])
    atom_sheets(wb, "A", ["Core laws", "Techs", "Units", "Terrain", "Buildings"])
    a_path = os.path.join(OUT, "atomspace-A-rulebook.xlsx")
    wb.save(a_path)

    # ---------------- B
    wb = Workbook()
    add_readme(wb, "Atomspace B — rulebook + everything visible on the board (initial state)", [
        "Atomspace B = every rulebook sheet (laws, stv 1.0 1.0) PLUS the world overlay sheets (observations,",
        "stv 1.0 0.99) generated from the real captured initial state, samples/real_state_turn1.json.",
        "",
        f"World overlay: {counts.get('World-Units',0)} unit facts, {counts.get('World-Affordances',0)} affordances "
        f"(the game's own validated options, incl. every legal move), {counts.get('World-Diplomacy',0)} diplomacy facts, "
        f"{counts.get('World-Meta',0)} meta facts. Quarantined: {counts.get('Quarantined',0)} raw fields visible in the feed but "
        "NOT asserted (contradictions/broken gauges) — see the Quarantined sheet.",
        "",
        "Lifetimes: the world overlay is EPHEMERAL — rebuilt from the state feed every turn and flushed at game end",
        "(unit/tile ids are per-game). The rulebook and player layers persist unchanged across turns and games.",
        "",
        "The Derived sheet shows what one chaining pass (chain.py, lib_pln Modus Ponens semantics) concludes from",
        "this space + the player layer (goals/strategy/hypotheses in player.metta): 159 new atoms, up to 4 hops.",
        "",
        stamp,
    ])
    atom_sheets(wb, "A", ["Core laws", "Techs", "Units", "Terrain", "Buildings"])
    atom_sheets(wb, "B", ["World-Meta", "World-Units", "World-Affordances", "World-Diplomacy"])

    # player layer (goals / strategy / hypotheses) from player.metta
    import chain as chainmod
    psrc = os.path.join(HERE, "player.metta")
    psent = chainmod.load_sentences(psrc)
    ens = [ln.split("; EN:", 1)[1].strip() for ln in open(psrc, encoding="utf-8")
           if "; EN:" in ln]
    ws = wb.create_sheet("Player layer")
    prows = [[layer, chainmod.unparse(t), en, f, c, "player.metta"]
             for (t, f, c, layer), en in zip(psent, ens)]
    sheet_rows(ws, ["Layer", "Atom (PLN word-form)", "Plain English", "f", "c", "Source"],
               prows, [16, 72, 64, 6, 6, 16], mono_cols=(2,))

    qs = [r for r in ROWS if r["sheet"] == "Quarantined"]
    ws = wb.create_sheet("Quarantined")
    sheet_rows(ws, ["Raw field(s) in the feed", "Why no atom was asserted"],
               [[r["source"], r["en"]] for r in qs], [52, 96])

    # hypotheses summary + derived atoms from the chain run
    hyp = [n for n in TRACE if n["layer"] == "hypotheses"]
    gp = [n for n in TRACE if n["atom"].startswith("(GoalProgress") and n.get("rule")]
    ws = wb.create_sheet("Hypotheses")
    hrows = []
    for h in hyp:
        mine = [g for g in gp if h["atom"] in g.get("hypo", [])]
        if mine:
            for g in sorted(mine, key=lambda g: g["depth"]):
                hrows.append([h["atom"], g["atom"], en_derived(g["atom"]), g["depth"]])
        else:
            hrows.append([h["atom"], "(none)", "Predicts no goal progress — null hypothesis.", ""])
    sheet_rows(ws, ["Hypothesis (assumed action)", "Predicted goal progress (provenance-tracked)", "Plain English", "Hops"],
               hrows, [44, 52, 52, 7], mono_cols=(1, 2))

    ws = wb.create_sheet("Derived")
    scaffolding = sum(1 for n in TRACE if n.get("rule") and n["atom"].startswith("(Implication"))
    drows = [[n["atom"], en_derived(n["atom"]), n["stv"][0], n["stv"][1], n["depth"],
              "; ".join(n.get("hypo", [])), n.get("fact") or "", n.get("rule") or ""]
             for n in sorted(TRACE, key=lambda x: (x["depth"], x["atom"]))
             if n.get("rule") and not n["atom"].startswith("(Implication")]
    drows.append([f"(+{scaffolding} curried intermediate implications not shown — scaffolding steps of multi-premise laws)",
                  "", "", "", "", "", "", ""])
    sheet_rows(ws, ["Derived atom", "Plain English", "f", "c", "Hops", "Depends on hypothesis", "From fact", "Via rule"],
               drows, [56, 42, 6, 6, 6, 40, 50, 60], mono_cols=(1, 6, 7, 8))

    b_path = os.path.join(OUT, "atomspace-B-initial-world.xlsx")
    wb.save(b_path)
    print("wrote", a_path)
    print("wrote", b_path)


if __name__ == "__main__":
    main()
