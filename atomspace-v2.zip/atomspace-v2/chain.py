"""Host-side chaining mirror for atomspace_v2.metta.

Implements exactly lib_pln's word-form Modus Ponens clause (lib_pln.metta:197)
    (|~ (A tv1) ((Implication A B) tv2))  ->  (B  MP(tv1, tv2))
with the real truth formula (lib_pln.metta:105):
    f' = f*fr + 0.02*(1-f)        c' = f*fr*c*cr
run forward to a fixpoint, so curried implications chain (a derived Implication
joins the rule pool). Provenance is tracked per derivation, which lets us score
each hypothesis by the (GoalProgress ...) conclusions that depend on it.

This is a design mirror for review + visualization on hosts without PeTTa —
the shape and math match the engine, but in-container gate-verification
(sh /PeTTa/run.sh ...) is the authoritative check before any live run.

Usage: python3 chain.py [--json OUT]     (stdlib only)
"""

import argparse
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "atomspace_v2.metta")

# ------------------------------------------------------------------ s-expressions

def parse_sexpr(s, pos=0):
    """Parse one s-expression starting at pos; return (tree, next_pos)."""
    while pos < len(s) and s[pos].isspace():
        pos += 1
    if pos >= len(s):
        raise ValueError("eof")
    if s[pos] == "(":
        pos += 1
        node = []
        while True:
            while pos < len(s) and s[pos].isspace():
                pos += 1
            if pos >= len(s):
                raise ValueError("unbalanced")
            if s[pos] == ")":
                return node, pos + 1
            child, pos = parse_sexpr(s, pos)
            node.append(child)
    m = re.match(r"[^\s()]+", s[pos:])
    return m.group(0), pos + m.end()


def unparse(t):
    return "(" + " ".join(unparse(x) for x in t) + ")" if isinstance(t, list) else str(t)


def strip_comments(text):
    return "\n".join(ln.split(";", 1)[0] for ln in text.splitlines())


def load_sentences(path):
    """Pull every ((<atom>) (stv f c)) sentence out of the superpose groups."""
    text = strip_comments(open(path, encoding="utf-8").read())
    sentences = []  # (tree, f, c, layer)
    for m in re.finditer(r"\(=\s*\((\w[\w-]*)\)\s*\(superpose\s*\(", text):
        layer = m.group(1)
        pos = m.end() - 1  # at the '(' opening the superpose list
        body, _ = parse_sexpr(text, pos)
        for item in body:
            if (isinstance(item, list) and len(item) == 2 and isinstance(item[1], list)
                    and item[1][:1] == ["stv"]):
                sentences.append((item[0], float(item[1][1]), float(item[1][2]), layer))
    return sentences

# ------------------------------------------------------------------- unification

def is_var(t):
    return isinstance(t, str) and t.startswith("$")


def unify(pat, grd, env):
    if is_var(pat):
        if pat in env:
            return unify(env[pat], grd, env)
        env = dict(env)
        env[pat] = grd
        return env
    if isinstance(pat, str) or isinstance(grd, str):
        return env if pat == grd else None
    if len(pat) != len(grd):
        return None
    for p, g in zip(pat, grd):
        env = unify(p, g, env)
        if env is None:
            return None
    return env


def subst(t, env):
    if is_var(t):
        v = env.get(t, t)
        return subst(v, env) if is_var(v) and v in env and env[v] is not t else (subst(v, env) if isinstance(v, list) else v)
    if isinstance(t, list):
        return [subst(x, env) for x in t]
    return t

# --------------------------------------------------------------- forward chainer

def mp_truth(f, c, fr, cr):
    return (f * fr + 0.02 * (1 - f), f * fr * c * cr)


# ------------------------------------------------------- grounded functions
# The numeric escape hatch every real symbolic stack has: OpenCog's
# GroundedSchemaNode ("py:fn"), Hyperon's plain MeTTa function definitions.
# Symbols bind via unification; THESE compute. Results re-enter the space as
# ordinary atoms (or as the truth value, via the AsTruth special form).

def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


GROUNDED = {}


def _fmtnum(x):
    return ("%.4f" % x).rstrip("0").rstrip(".") if x != int(x) else str(int(x))


GROUNDED["Mul"] = lambda *a: _fmtnum(__import__("math").prod(float(x) for x in a))
GROUNDED["VetFactor"] = lambda v: {"Green": "1.0", "Veteran": "1.5",
                                   "Hardened": "1.75", "Elite": "2.0"}.get(v)
GROUNDED["DefBonusFactor"] = lambda pct: _fmtnum(1 + float(pct) / 100)
GROUNDED["FortFactor"] = lambda fs: {"Fortified": "1.5", "Unfortified": "1.0"}.get(fs)
GROUNDED["OddsBucket"] = lambda p: ("Favorable" if float(p) >= 0.55 else
                                    "Unfavorable" if float(p) < 0.45 else "Coinflip")


def _battle_win_prob(A, D, fa, hd, fd, ha):
    """P(attacker kills defender first). Freeciv round: attacker hits with
    p = A/(A+D), removing fa HP from defender; else defender removes fd from
    attacker. Exact DP over (defender_hp, attacker_hp)."""
    A, D, fa, hd, fd, ha = float(A), float(D), int(fa), int(hd), int(fd), int(ha)
    if A <= 0:
        return "0"
    p = A / (A + D)
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def win(dh, ah):
        if dh <= 0:
            return 1.0
        if ah <= 0:
            return 0.0
        return p * win(dh - fa, ah) + (1 - p) * win(dh, ah - fd)

    return _fmtnum(win(hd, ha))


GROUNDED["BattleWinProb"] = _battle_win_prob


def ground_eval(t):
    """Bottom-up: evaluate any (Fn arg...) whose head is grounded and whose args
    are all ground tokens. Unevaluable subtrees are left as-is."""
    if isinstance(t, str):
        return t
    t = [ground_eval(x) for x in t]
    if t and isinstance(t[0], str) and t[0] in GROUNDED and all(isinstance(a, str) for a in t[1:]):
        try:
            r = GROUNDED[t[0]](*t[1:])
            if r is not None:
                return r
        except Exception:
            pass
    return t


def fmt(x):
    return ("%.3f" % x).rstrip("0").rstrip(".")


class Node:
    __slots__ = ("tree", "key", "f", "c", "layer", "rule", "fact", "bases", "depth")

    def __init__(self, tree, f, c, layer, rule=None, fact=None):
        self.tree, self.f, self.c, self.layer = tree, f, c, layer
        self.key = unparse(tree) if isinstance(tree, list) else str(tree)
        self.rule, self.fact = rule, fact           # parents of a derived node
        self.bases = ({self.key} if rule is None else (rule.bases | fact.bases))
        self.depth = 0 if rule is None else max(rule.depth, fact.depth) + 1


def ground_syms(t, out=None):
    out = set() if out is None else out
    if isinstance(t, str):
        if not is_var(t):
            out.add(t)
    else:
        for x in t:
            ground_syms(x, out)
    return out


def chain(sentences, max_rounds=24):
    nodes = {}
    for tree, f, c, layer in sentences:
        n = Node(tree, f, c, layer)
        if n.key not in nodes or c > nodes[n.key].c:
            nodes[n.key] = n
    for _ in range(max_rounds):
        rules = [n for n in nodes.values() if isinstance(n.tree, list) and n.tree[:1] == ["Implication"]]
        facts = list(nodes.values())
        # symbol index: candidate facts must contain every ground symbol of the premise
        sym2facts = {}
        for fa in facts:
            for s in ground_syms(fa.tree):
                sym2facts.setdefault(s, []).append(fa)
        new = []
        for r in rules:
            prem, concl = r.tree[1], r.tree[2]
            syms = ground_syms(prem)
            if syms:
                rarest = min(syms, key=lambda s: len(sym2facts.get(s, [])))
                cands = sym2facts.get(rarest, [])
            else:
                cands = facts
            for fa in cands:
                if fa.key == r.key:
                    continue
                env = unify(prem, fa.tree, {})
                if env is None:
                    continue
                out = ground_eval(subst(concl, env))
                f2, c2 = mp_truth(fa.f, fa.c, r.f, r.c)
                # (AsTruth <p> <atom>): a grounded probability becomes the
                # derived atom's FREQUENCY; confidence stays premise-propagated.
                if (isinstance(out, list) and out[:1] == ["AsTruth"]
                        and len(out) == 3 and _num(out[1]) is not None):
                    f2, out = _num(out[1]), out[2]
                n = Node(out, f2, c2, "derived", rule=r, fact=fa)
                old = nodes.get(n.key)
                if old is None or c2 > old.c + 1e-9:
                    new.append(n)
        if not new:
            break
        for n in new:
            nodes[n.key] = n
    return nodes


def trace(n, indent=0):
    pad = "  " * indent
    tag = "" if n.rule is None else "  <= MP"
    line = f"{pad}{'derived' if n.rule else n.layer:>18} | (stv {fmt(n.f)} {fmt(n.c)}) {n.key}{tag}"
    out = [line]
    if n.rule is not None:
        out += trace(n.fact, indent + 1)
        out += [f"{'  ' * (indent + 1)}{'rule':>18} | (stv {fmt(n.rule.f)} {fmt(n.rule.c)}) {n.rule.key}"
                if n.rule.rule is None else None]
        if n.rule.rule is not None:
            out[-1:] = trace(n.rule, indent + 1)
    return [l for l in out if l]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default=None)
    ap.add_argument("--src", action="append", default=None,
                    help="metta file(s) to load; repeatable. Default: atomspace_v2.metta")
    args = ap.parse_args()

    sentences = []
    for path in (args.src or [SRC]):
        sentences += load_sentences(path if os.path.isabs(path) else os.path.join(HERE, path))
    base_hypos = [unparse(t) for t, f, c, layer in sentences
                  if layer == "hypotheses" or (isinstance(t, list) and t[:1] == ["Do"])]
    n_layers = {}
    for _, _, _, layer in sentences:
        n_layers[layer] = n_layers.get(layer, 0) + 1
    print("loaded:", ", ".join(f"{v} {k}" for k, v in n_layers.items()))

    nodes = chain(sentences)
    derived = [n for n in nodes.values() if n.rule is not None]
    print(f"derived: {len(derived)} new atoms (max depth {max((n.depth for n in derived), default=0)})\n")

    recs = [n for n in derived if isinstance(n.tree, list) and n.tree[:1] == ["Recommend"]]
    print("=" * 76)
    print("RECOMMENDATIONS (goal-linked, with full derivation chains)")
    print("=" * 76)
    for n in sorted(recs, key=lambda x: -x.c):
        print()
        print("\n".join(trace(n)))

    print()
    print("=" * 76)
    print("HYPOTHESIS SCORING — predicted goal progress per assumed action")
    print("=" * 76)
    gp = [n for n in derived if isinstance(n.tree, list) and n.tree[:1] == ["GoalProgress"]]
    for h in base_hypos:
        wins = [n for n in gp if h in n.bases]
        print(f"\n  {h}")
        if not wins:
            print("      -> predicts NO goal progress (null hypothesis)")
        for n in sorted(wins, key=lambda x: -x.c):
            print(f"      -> (stv {fmt(n.f)} {fmt(n.c)}) {n.key}   [{n.depth} hops]")

    others = [n for n in derived if not (isinstance(n.tree, list) and n.tree[0] in ("Recommend", "GoalProgress"))]
    print()
    print("=" * 76)
    print(f"OTHER DERIVED KNOWLEDGE ({len(others)} atoms)")
    print("=" * 76)
    for n in sorted(others, key=lambda x: (x.depth, x.key)):
        print(f"  [{n.depth} hop] (stv {fmt(n.f)} {fmt(n.c)}) {n.key}")

    if args.json:
        hypo_keys = set(base_hypos)
        payload = [{"atom": n.key, "stv": [round(n.f, 4), round(n.c, 4)], "depth": n.depth,
                    "layer": n.layer, "rule": n.rule.key if n.rule else None,
                    "fact": n.fact.key if n.fact else None,
                    "hypo": sorted(n.bases & hypo_keys)} for n in nodes.values()]
        json.dump(payload, open(args.json, "w"), indent=1)
        print("\nwrote", args.json)


if __name__ == "__main__":
    main()
