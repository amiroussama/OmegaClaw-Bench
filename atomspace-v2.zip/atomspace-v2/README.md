# FreeCiv atomspaces — A (rulebook) and B (rulebook + world)

Three layers, three lifetimes:

| File | Layer | Truth | Lifetime |
|---|---|---|---|
| `rulebook.metta` (**Atomspace A**, generated) | laws of the game: rules of play, all 87 techs, 52 units, 14 terrains, 68 buildings | `(stv 1.0 1.0)` | permanent — true in every game, every turn |
| `player.metta` (hand-written) | goals, strategy heuristics, hypotheses under consideration | goals `1.0 1.0`; heuristics hedge on frequency; hypotheses `1.0 0.9` | persistent but *editable* — where learned strategy accumulates |
| `world_turn1.metta` (**overlay**, generated) | everything visible on the board this turn | `(stv 1.0 0.99)` | **ephemeral** — rebuilt from the state feed every turn, flushed at game end |

**Atomspace B = A + overlay** (load them together). `chain.py` is the reasoning demo.

## The reset / "crud" question

Instance atoms (`Unit_102`, `Tile_14_42`) appear **only** in the overlay. The overlay is a pure
function of the proxy state (same design as Rojo's adapter), so each turn it is regenerated
whole and the previous one discarded — nothing accumulates, and at game end there is nothing to
clean because nothing instance-bound ever entered the persistent layers. Unit and tile ids are
server-assigned *per game*, so this flush is mandatory, not just hygiene. Anything the system
*learns* must be expressed over types and predicates (`$u`, `Type_settlers`, `$tech`) and stored
in the player layer — context-independent templates, exactly as intuited. The generator enforces
the boundary: no `Unit_`/`Tile_` token is ever emitted into `rulebook.metta`.

## Regenerate

```bash
python3 build_atomspaces.py       # ruleset/ + captured state -> rulebook.metta, world_turn1.metta, rows.json
python3 chain.py --src rulebook.metta --src world_turn1.metta --src player.metta --json trace_full.json
python3 build_spreadsheets.py     # -> ../atomspace-A-rulebook.xlsx, ../atomspace-B-initial-world.xlsx
```

`build_atomspaces.py --help`: point it at a different ruleset dir or captured state as needed.
`chain.py` mirrors lib_pln's Modus Ponens clause + truth formula (`lib_pln.metta:105,197`) on the
host; the authoritative check is running the space in-container on PeTTa.

## Known gaps (honest list)

- **Effect semantics**: buildings carry cost/upkeep/prereqs, but what each *does* (Granary halves
  growth food, etc.) lives in `effects.ruleset` and is not yet encoded.
- **Combat** is one summary law (attack vs defense × modifiers), not the full resolution table.
- **Ruleset assumption**: `ruleset/` is FreeCiv *classic* from `freeciv/freeciv@main` (GPL data,
  © the Freeciv project — kept here for analysis, do not vendor into the MIT repo). If the
  freeciv-llm stack pins a different ruleset, re-point and regenerate.
- **Negative affordances** (`is_valid: false` + reason) are real knowledge, currently quarantined.
- Terrain laws stand ready, but `map.tiles` was empty in this capture — no terrain observations yet.

`atomspace_v2.metta` is the original 57-atom worked example from the 7/17 report (kept for
reference; A/B supersede it).
